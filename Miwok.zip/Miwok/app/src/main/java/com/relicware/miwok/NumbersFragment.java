package com.relicware.miwok;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class NumbersFragment extends Fragment {


    public NumbersFragment() {
        // Required empty public constructor
    }

    @Override
    public void onStop() {
        super.onStop();
        Translation.stopSound();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.card_list, container, false);

        ArrayList<Translation> numbers = new ArrayList<>();
        numbers.add(new Translation("one", "ایک", new Image(R.drawable.number_one), new Sound(R.raw.number_one)));
        numbers.add(new Translation("two", "دو", new Image(R.drawable.number_two), new Sound(R.raw.number_two)));
        numbers.add(new Translation("three", "تین", new Image(R.drawable.number_three), new Sound(R.raw.number_three)));
        numbers.add(new Translation("four", "چار", new Image(R.drawable.number_four), new Sound(R.raw.number_four)));
        numbers.add(new Translation("five", "پانچ", new Image(R.drawable.number_five), new Sound(R.raw.number_five)));
        numbers.add(new Translation("six", "چھ", new Image(R.drawable.number_six), new Sound(R.raw.number_six)));
        numbers.add(new Translation("seven", "سات", new Image(R.drawable.number_seven), new Sound(R.raw.number_seven)));
        numbers.add(new Translation("eight", "آٹھ", new Image(R.drawable.number_eight), new Sound(R.raw.number_eight)));
        numbers.add(new Translation("nine", "نو", new Image(R.drawable.number_nine), new Sound(R.raw.number_nine)));
        numbers.add(new Translation("ten", "دس", new Image(R.drawable.number_ten), new Sound(R.raw.number_ten)));

        TranslationAdapter adapter = new TranslationAdapter(numbers);

        final RecyclerView list = rootView.findViewById(R.id.items_list);
        list.setHasFixedSize(true);
        list.setLayoutManager(new LinearLayoutManager(getActivity()));
        list.setAdapter(adapter);

        adapter.setOnItemClickListener((i, v) -> {
            Toast.makeText(getActivity(), "you clicked number: " + numbers.get(i).getMiwokWord(), Toast.LENGTH_SHORT).show();
            numbers.get(i).playSound(getActivity());
        });

        return rootView;
    }
}
