package com.relicware.miwok;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class PhrasesFragment extends Fragment {


    public PhrasesFragment() {
        // Required empty public constructor
    }


    @Override
    public void onStop() {
        super.onStop();
        Translation.stopSound();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.card_list, container, false);

        ArrayList<Translation> phrases = new ArrayList<>();
        phrases.add(new Translation("how are you?", "kia haal he?", new Sound(R.raw.phrase_how_are_you_feeling)));
        phrases.add(new Translation("i am going", "me ja raha hu", new Sound(R.raw.phrase_are_you_coming)));
        phrases.add(new Translation("i am eating", "me kha raha hu", new Sound(R.raw.phrase_im_coming)));

        TranslationAdapter adapter = new TranslationAdapter(phrases);

        final RecyclerView list = rootView.findViewById(R.id.items_list);
        list.setHasFixedSize(true);
        list.setLayoutManager(new LinearLayoutManager(getActivity()));
        list.setAdapter(adapter);

        adapter.setOnItemClickListener((i, v) -> {
            Toast.makeText(getActivity(), "you clicked phrase: " + phrases.get(i).getMiwokWord(), Toast.LENGTH_SHORT).show();
            phrases.get(i).playSound(getActivity());
        });
        return rootView;
    }

}
