package com.relicware.miwok;

import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Muhammad on 09-Mar-18.
 */


import android.view.LayoutInflater;
import android.view.ViewGroup;

import java.util.ArrayList;

public class TranslationAdapter extends RecyclerView.Adapter<TranslationAdapter.TranslationViewHolder> {
    private ArrayList<Translation> mDataset;
    private MyClickListener myClickListener;


    public class TranslationViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView miwokWord, defaultWord;
        CardView imageCard;
        public TranslationViewHolder(View view) {
            super(view);
            miwokWord = view.findViewById(R.id.miwok_word);
            defaultWord = view.findViewById(R.id.defaut_word);
            imageCard = view.findViewById(R.id.card_image);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            myClickListener.onItemClick(getAdapterPosition(), v);
        }
    }


    public void setOnItemClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }

    public TranslationAdapter(ArrayList<Translation> myDataset) {
        super();
        mDataset = myDataset;
    }

    @Override
    public TranslationViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new TranslationViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.card, parent, false));
    }

    @Override
    public void onBindViewHolder(TranslationViewHolder holder, int position) {
        holder.miwokWord.setText(mDataset.get(position).getMiwokWord());
        holder.defaultWord.setText(mDataset.get(position).getDefaultWord());
        if(mDataset.get(position).hasImage()) {
            ((ImageView) holder.imageCard.getChildAt(0)).setImageResource(mDataset.get(position).getImage().getId());
        }
        else holder.imageCard.setVisibility(View.GONE);
    }

    public void addItem(Translation dataObj, int index) {
        mDataset.add(index, dataObj);
        notifyItemInserted(index);
    }

    public void deleteItem(int index) {
        mDataset.remove(index);
        notifyItemRemoved(index);
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    public interface MyClickListener {
        public void onItemClick(int position, View v);
    }
}
