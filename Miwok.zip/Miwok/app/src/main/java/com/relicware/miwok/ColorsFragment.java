package com.relicware.miwok;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class ColorsFragment extends Fragment {


    public ColorsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onStop() {
        super.onStop();
        Translation.stopSound();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.card_list, container, false);

        ArrayList<Translation> colors = new ArrayList<>();
        colors.add(new Translation("red", "سرخ", new Image(R.drawable.color_red)));
        colors.add(new Translation("green", "سبز", new Image(R.drawable.color_green)));
        colors.add(new Translation("black", "سیاہ", new Image(R.drawable.color_black)));
        colors.add(new Translation("gray","سرمئی", new Image(R.drawable.color_gray)));
        colors.add(new Translation("yellow", "پیلا", new Image(R.drawable.color_mustard_yellow)));
        colors.add(new Translation("white", "سفید", new Image(R.drawable.color_white)));

        TranslationAdapter adapter = new TranslationAdapter(colors);

        final RecyclerView list = rootView.findViewById(R.id.items_list);
        list.setHasFixedSize(true);
        list.setLayoutManager(new LinearLayoutManager(getActivity()));
        list.setAdapter(adapter);

        adapter.setOnItemClickListener((i, v) -> {
            Toast.makeText(getActivity(), "you clicked color: " + colors.get(i).getMiwokWord(), Toast.LENGTH_SHORT).show();
            colors.get(i).playSound(getActivity());
        });

        return rootView;
    }

}
