package com.relicware.miwok;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.util.Log;

/**
 * Created by Muhammad on 08-Mar-18.
 */
class Image {
    private int mId;

    public Image(int id) {
        mId = id;
    }

    public int getId() {
        return mId;
    }
}

class Sound {
    private int mId;

    public Sound(int id) {
        mId = id;
    }

    public int getId() {
        return mId;
    }
}

class Translation {
    private String mDefaultWord, mMiwokWord;
    private Image mImage = null;
    private Sound mSound = null;

    private static MediaPlayer mMediaPlayer = null;
    private static AudioManager mAudioManager = null;

    public Translation(String defaultWord, String miwokWord, Image image, Sound sound) {
        mDefaultWord = defaultWord;
        mMiwokWord = miwokWord;
        mImage = image;
        mSound = sound;
    }

    public Translation(String defaultWord, String miwokWord, Sound soundId) {
        mDefaultWord = defaultWord;
        mMiwokWord = miwokWord;
        mSound = soundId;
    }

    public Translation(String defaultWord, String miwokWord, Image imageId) {
        mDefaultWord = defaultWord;
        mMiwokWord = miwokWord;
        mImage = imageId;
    }

    public Translation(String defaultWord, String miwokWord) {
        mDefaultWord = defaultWord;
        mMiwokWord = miwokWord;
    }

    private static AudioManager.OnAudioFocusChangeListener afChangeListener = (focusChange) -> {
        if (focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            // Pause playback because your Audio Focus was
            // temporarily stolen, but will be back soon.
            // i.e. for a phone call
            if (mMediaPlayer != null) mMediaPlayer.pause();
            Log.d("audioFocusChange", "AUDIOFOCUS_LOSS_TRANSIENT");
        } else if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
            // Stop playback, because you lost the Audio Focus.
            // i.e. the user started some other playback app
            // Remember to unregister your controls/buttons here.
            // And release the kra — Audio Focus!
            // You’re done.
            stopSound();
            Log.d("audioFocusChange", "AUDIOFOCUS_LOSS");
        } else if (focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
            // Lower the volume, because something else is also
            // playing audio over you.
            // i.e. for notifications or navigation directions
            // Depending on your audio playback, you may prefer to
            // pause playback here instead. You do you.

            Log.d("audioFocusChange", "CAN DUCK");
        } else if (focusChange == AudioManager.AUDIOFOCUS_GAIN) {
            // Resume playback, because you hold the Audio Focus
            // again!
            // i.e. the phone call ended or the nav directions
            // are finished
            // If you implement ducking and lower the volume, be
            // sure to return it to normal here, as well.

            Log.d("audioFocusChange", "AUDIOFOCUS_GAIN");
            if (mMediaPlayer != null) mMediaPlayer.start();
        }
    };

    public static void stopSound() {
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
            mMediaPlayer = null;
        }
        if(mAudioManager != null) mAudioManager.abandonAudioFocus(afChangeListener);
    }

    public boolean playSound(Context context) {
        if (hasSound()) {
            if (mMediaPlayer != null) {
                mMediaPlayer.stop();
                mMediaPlayer.release();
                mMediaPlayer = null;
            }

            if (mAudioManager == null)
                mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            mAudioManager.requestAudioFocus(afChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);

            mMediaPlayer = MediaPlayer.create(context, mSound.getId());
            mMediaPlayer.setOnCompletionListener((mediaPlayer) -> stopSound());
            mMediaPlayer.start();

            return true;
        } else return false;
    }

    public String getDefaultWord() {
        return mDefaultWord;
    }

    public String getMiwokWord() {
        return mMiwokWord;
    }

    public Image getImage() {
        return mImage;
    }

    public Sound getSound() {
        return mSound;
    }

    public boolean hasImage() {
        return mImage != null;
    }

    public boolean hasSound() {
        return mSound != null;
    }
}
