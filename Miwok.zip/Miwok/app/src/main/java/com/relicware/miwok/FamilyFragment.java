package com.relicware.miwok;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class FamilyFragment extends Fragment {


    public FamilyFragment() {
        // Required empty public constructor
    }

    @Override
    public void onStop() {
        super.onStop();
        Translation.stopSound();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.card_list, container, false);

        ArrayList<Translation> fmembers = new ArrayList<>();
        fmembers.add(new Translation("father", "baap", new Image(R.drawable.family_father)));
        fmembers.add(new Translation("mother", "maan", new Image(R.drawable.family_mother)));
        fmembers.add(new Translation("brother", "bhai", new Image(R.drawable.family_older_brother)));
        fmembers.add(new Translation("younger brother", "chota", new Image(R.drawable.family_younger_brother)));
        fmembers.add(new Translation("sister", "bhen", new Image(R.drawable.family_older_sister)));
        fmembers.add(new Translation("younger sister", "choti", new Image(R.drawable.family_younger_sister)));

        TranslationAdapter adapter = new TranslationAdapter(fmembers);

        final RecyclerView list = rootView.findViewById(R.id.items_list);
        list.setHasFixedSize(true);
        list.setLayoutManager(new LinearLayoutManager(getActivity()));
        list.setAdapter(adapter);

        adapter.setOnItemClickListener((i, v) -> {
            Toast.makeText(getActivity(), "you clicked family: " + fmembers.get(i).getMiwokWord(), Toast.LENGTH_SHORT).show();
            fmembers.get(i).playSound(getActivity());
        });
        return rootView;
    }

}
